function out = bigger_process(image_in)
image = image_in;
[h,w,z] = size(image);

H = 2 * h;
W = 2 * w;

image_new = ones(H,W,3);

for y = 1:2:H
    for x = 1:2:W
        pixel = [image((y+1)/2, (x+1)/2, 1), image((y+1)/2, (x+1)/2, 2), image((y+1)/2, (x+1)/2, 3)];
        image_new(y,x,:) = pixel;
        image_new(y+1,x,:) = pixel;
        image_new(y,x+1,:) = pixel;
        image_new(y+1,x+1,:) = pixel;
    end
end

out = image_new;